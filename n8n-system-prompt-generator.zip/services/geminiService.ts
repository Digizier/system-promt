import { GoogleGenAI, Type } from "@google/genai";
import { FormData, PromptHeader } from '../types';

// Helper to get client
const getClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) throw new Error("API Key not found");
  return new GoogleGenAI({ apiKey });
};

export const generateClarifyingQuestions = async (
  intent: string,
  workflowJson: string
): Promise<string[]> => {
  const ai = getClient();
  
  // Truncate JSON if it's massive to avoid token limits, though Gemini context is large.
  const safeJson = workflowJson.length > 50000 ? workflowJson.substring(0, 50000) + "...(truncated)" : workflowJson;

  const prompt = `
    I am building an n8n workflow. 
    User Goal: ${intent}
    Workflow Data (JSON snippet): ${safeJson}
    
    Please analyze the workflow and the goal. Generate exactly 3 to 5 short, relevant clarifying questions that you need to ask the user to create the perfect "System Prompt" for the AI node in this workflow.
    Focus on nuances like tone, edge cases, or specific data handling that isn't clear from the JSON.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.STRING
          }
        }
      }
    });

    const text = response.text;
    if (!text) return ["Could not generate questions. Please proceed."];
    return JSON.parse(text) as string[];
  } catch (error) {
    console.error("Gemini Error:", error);
    return ["What is the specific tone you want?", "Are there any strict prohibitions?", "How should undefined inputs be handled?"];
  }
};

export const generateExecutionPlan = async (formData: FormData): Promise<string[]> => {
    const ai = getClient();
    
    const prompt = `
      User wants an n8n System Prompt.
      Intent: ${formData.buildIntent}
      Model: ${formData.model}
      Selected Headers: ${formData.selectedHeaders.filter(h => h.selected).map(h => h.label).join(', ')}
      
      Based on this, list 3-5 bullet points describing how you will construct this prompt to make it "World Class". 
      E.g., "I will structure the role to enforce strict JSON output", "I will add specific constraints for the provided tools".
    `;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-3-flash-preview",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING }
                }
            }
        });
        const text = response.text;
        return text ? JSON.parse(text) : ["Analyze requirements", "Draft structure", "Optimize for model"];
    } catch (e) {
        return ["Analyze workflow context", "Integrate user constraints", "Format according to n8n best practices"];
    }
}

export const generateFinalSystemPrompt = async (formData: FormData): Promise<string> => {
  const ai = getClient();

  const selectedHeadersText = formData.selectedHeaders
    .filter(h => h.selected)
    .map(h => {
        let line = `- ${h.label}`;
        if (h.id === 23 && h.inputValue) {
            line += ` (User specified output parser details: ${h.inputValue})`;
        }
        return line;
    })
    .join('\n');

  const qaText = Object.entries(formData.userAnswers)
    .map(([index, answer]) => `Q: ${formData.aiQuestions[parseInt(index)]}\nA: ${answer}`)
    .join('\n');

  const prompt = `
    Act as a World-Class n8n Workflow System Prompt Engineer.
    
    # Context
    User Goal: ${formData.buildIntent}
    Target Model: ${formData.model}
    Character Limit Target: ${formData.characterCount || "No strict limit, optimize for quality"}
    Tools Available: ${formData.tools}
    Expected Input: ${formData.expectedInput}
    Expected Output: ${formData.expectedOutput}
    
    # Workflow Context (JSON)
    ${formData.workflowJson.substring(0, 30000)}
    
    # User Clarifications
    ${qaText}
    
    # Structure Requirements
    You MUST include the following sections in the System Prompt:
    ${selectedHeadersText}
    
    # Instructions
    Generate the final System Prompt. 
    - Use Markdown formatting (## for main sections, - for lists, ** for emphasis).
    - Be highly specific to n8n operations.
    - If "Output Structure Parser" is requested, ensure the prompt explicitly defines the schema.
    - The tone should be authoritative yet helpful for the LLM executing the task.
    
    OUTPUT ONLY THE SYSTEM PROMPT CONTENT IN MARKDOWN.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
    });

    return response.text || "**Error generating prompt.**";
  } catch (error) {
    console.error("GenAI Error", error);
    return "An error occurred while generating the system prompt. Please check your API key and try again.";
  }
};