import React from 'react';
import ReactMarkdown from 'react-markdown';
import { FormData } from '../types';

interface Props {
  prompt: string;
  onReset: () => void;
  isLoading: boolean;
}

const ResultDisplay: React.FC<Props> = ({ prompt, onReset, isLoading }) => {
  const [copied, setCopied] = React.useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(prompt);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 space-y-4">
        <div className="w-12 h-12 border-4 border-n8n-primary border-t-transparent rounded-full animate-spin"></div>
        <p className="text-gray-600 font-medium">Generating your world-class system prompt...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in h-full flex flex-col">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-n8n-secondary">Generated System Prompt</h2>
        <div className="space-x-3">
            <button
                onClick={onReset}
                className="px-4 py-2 text-sm font-medium text-gray-600 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
            >
                Start Over
            </button>
            <button
                onClick={handleCopy}
                className={`px-4 py-2 text-sm font-medium text-white rounded-md transition-colors ${
                    copied ? 'bg-green-600' : 'bg-n8n-primary hover:bg-orange-600'
                }`}
            >
                {copied ? 'Copied!' : 'Copy to Clipboard'}
            </button>
        </div>
      </div>

      <div className="flex-1 overflow-hidden bg-gray-900 rounded-lg shadow-inner border border-gray-700">
        <div className="h-[600px] overflow-auto p-6 custom-scrollbar">
            {/* Using a prose class wrapper for markdown styling */}
            <div className="prose prose-invert max-w-none prose-headings:text-n8n-primary prose-a:text-blue-400">
                <ReactMarkdown>{prompt}</ReactMarkdown>
            </div>
        </div>
      </div>
    </div>
  );
};

export default ResultDisplay;