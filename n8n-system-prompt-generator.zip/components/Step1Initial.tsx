import React from 'react';
import { FormData } from '../types';

interface Props {
  data: FormData;
  updateData: (fields: Partial<FormData>) => void;
  onNext: () => void;
}

const Step1Initial: React.FC<Props> = ({ data, updateData, onNext }) => {
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const text = await file.text();
      updateData({ workflowJson: text });
    }
  };

  const isFormValid = 
    data.buildIntent && 
    data.workflowJson && 
    data.model && 
    data.tools && 
    data.expectedInput && 
    data.expectedOutput;

  return (
    <div className="space-y-6 animate-fade-in">
      <h2 className="text-2xl font-bold text-n8n-secondary mb-4">Step 1: Project Basics</h2>
      
      {/* What to build */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          What do you want to build? <span className="text-red-500">*</span>
        </label>
        <textarea
          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-n8n-primary focus:border-n8n-primary transition"
          rows={3}
          placeholder="E.g., A customer support agent that classifies emails and drafts replies..."
          value={data.buildIntent}
          onChange={(e) => updateData({ buildIntent: e.target.value })}
        />
      </div>

      {/* Workflow JSON */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          n8n Workflow JSON <span className="text-red-500">*</span>
        </label>
        <div className="flex items-center space-x-4">
            <input
            type="file"
            accept=".json"
            onChange={handleFileChange}
            className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-n8n-secondary/10 file:text-n8n-secondary hover:file:bg-n8n-secondary/20"
            />
        </div>
        <div className="mt-2">
            <textarea
                className="w-full p-2 text-xs font-mono border border-gray-300 rounded-md bg-gray-50 h-24"
                placeholder="Or paste JSON code here..."
                value={data.workflowJson}
                onChange={(e) => updateData({ workflowJson: e.target.value })}
            />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Model */}
        <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
            Model Used <span className="text-red-500">*</span>
            </label>
            <input
            type="text"
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-n8n-primary focus:border-n8n-primary"
            placeholder="e.g. GPT-4o, Gemini 1.5 Pro"
            value={data.model}
            onChange={(e) => updateData({ model: e.target.value })}
            />
        </div>
        
        {/* Char Count */}
        <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
            Max Character Count (?)
            </label>
            <input
            type="text"
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-n8n-primary focus:border-n8n-primary"
            placeholder="e.g. 2000"
            value={data.characterCount}
            onChange={(e) => updateData({ characterCount: e.target.value })}
            />
        </div>
      </div>

      {/* Tools */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Tools Access (N/A if none) <span className="text-red-500">*</span>
        </label>
        <input
          type="text"
          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-n8n-primary focus:border-n8n-primary"
          placeholder="e.g. Google Sheets, Slack API, Calculator"
          value={data.tools}
          onChange={(e) => updateData({ tools: e.target.value })}
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Input */}
        <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
            Expected Input <span className="text-red-500">*</span>
            </label>
            <textarea
            rows={2}
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-n8n-primary focus:border-n8n-primary"
            placeholder="User email body string"
            value={data.expectedInput}
            onChange={(e) => updateData({ expectedInput: e.target.value })}
            />
        </div>

        {/* Output */}
        <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
            Expected Output <span className="text-red-500">*</span>
            </label>
            <textarea
            rows={2}
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-n8n-primary focus:border-n8n-primary"
            placeholder="JSON with { sentiment, reply_draft }"
            value={data.expectedOutput}
            onChange={(e) => updateData({ expectedOutput: e.target.value })}
            />
        </div>
      </div>

      <div className="flex justify-end pt-4">
        <button
          onClick={onNext}
          disabled={!isFormValid}
          className={`px-6 py-3 rounded-lg font-semibold text-white transition-all ${
            isFormValid 
              ? 'bg-n8n-primary hover:bg-orange-600 shadow-lg hover:shadow-xl translate-y-0' 
              : 'bg-gray-400 cursor-not-allowed'
          }`}
        >
          Generate Questions &rarr;
        </button>
      </div>
    </div>
  );
};

export default Step1Initial;