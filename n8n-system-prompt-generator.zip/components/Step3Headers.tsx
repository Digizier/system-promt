import React from 'react';
import { FormData, PromptHeader } from '../types';

interface Props {
  data: FormData;
  updateData: (fields: Partial<FormData>) => void;
  onNext: () => void;
}

const Step3Headers: React.FC<Props> = ({ data, updateData, onNext }) => {
  const toggleHeader = (id: number) => {
    const newHeaders = data.selectedHeaders.map(h => {
      if (h.id === id) {
        return { ...h, selected: !h.selected };
      }
      return h;
    });
    updateData({ selectedHeaders: newHeaders });
  };

  const updateHeaderInput = (id: number, val: string) => {
    const newHeaders = data.selectedHeaders.map(h => {
        if (h.id === id) {
          return { ...h, inputValue: val };
        }
        return h;
      });
      updateData({ selectedHeaders: newHeaders });
  }

  // Check if output parser is selected but input is empty
  const isOutputParserInvalid = data.selectedHeaders.some(h => 
    h.id === 23 && h.selected && (!h.inputValue || h.inputValue.trim() === "")
  );

  return (
    <div className="space-y-6 animate-fade-in">
      <h2 className="text-2xl font-bold text-n8n-secondary mb-2">Step 3: Prompt Structure</h2>
      <p className="text-gray-600 mb-4">Select the sections you want to include in the System Prompt.</p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-[60vh] overflow-y-auto pr-2 custom-scrollbar">
        {data.selectedHeaders.map((header) => (
          <div 
            key={header.id} 
            className={`p-3 rounded-lg border transition-all ${
                header.selected 
                    ? 'border-n8n-secondary bg-n8n-secondary/5' 
                    : 'border-gray-200 hover:border-gray-300'
            }`}
          >
            <div className="flex items-start space-x-3">
                <div className="flex items-center h-5">
                    <input
                        type="checkbox"
                        disabled={header.required}
                        checked={header.selected}
                        onChange={() => !header.required && toggleHeader(header.id)}
                        className={`w-4 h-4 rounded text-n8n-secondary focus:ring-n8n-secondary ${header.required ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
                    />
                </div>
                <div className="w-full">
                    <label 
                        className={`text-sm font-medium ${header.required ? 'text-gray-500' : 'text-gray-900 cursor-pointer'}`}
                        onClick={() => !header.required && toggleHeader(header.id)}
                    >
                        {header.label} 
                        {header.required && <span className="text-xs text-n8n-primary ml-2">(Required)</span>}
                    </label>
                    
                    {/* Special input for Output Structure Parser */}
                    {header.id === 23 && header.selected && (
                        <div className="mt-2 animate-fade-in">
                            <label className="text-xs text-gray-500 block mb-1">
                                What output structure do you expect? (e.g., JSON Array of Strings, Markdown Table)
                            </label>
                            <input 
                                type="text" 
                                className="w-full text-sm p-2 border border-gray-300 rounded focus:border-n8n-primary outline-none"
                                value={header.inputValue || ""}
                                onChange={(e) => updateHeaderInput(header.id, e.target.value)}
                                placeholder="Describe format..."
                            />
                        </div>
                    )}
                </div>
            </div>
          </div>
        ))}
      </div>

      <div className="flex justify-end pt-4">
        <button
          onClick={onNext}
          disabled={isOutputParserInvalid}
          className={`px-6 py-3 rounded-lg font-semibold text-white transition-all ${
            !isOutputParserInvalid
              ? 'bg-n8n-primary hover:bg-orange-600 shadow-lg'
              : 'bg-gray-400 cursor-not-allowed'
          }`}
        >
          Generate Plan &rarr;
        </button>
      </div>
    </div>
  );
};

export default Step3Headers;