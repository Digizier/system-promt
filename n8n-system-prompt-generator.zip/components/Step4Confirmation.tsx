import React from 'react';
import { FormData } from '../types';

interface Props {
  data: FormData;
  onNext: () => void;
  isLoading: boolean;
}

const Step4Confirmation: React.FC<Props> = ({ data, onNext, isLoading }) => {
  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 space-y-4">
        <div className="w-12 h-12 border-4 border-n8n-primary border-t-transparent rounded-full animate-spin"></div>
        <p className="text-gray-600 font-medium">Formulating execution plan...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <h2 className="text-2xl font-bold text-n8n-secondary mb-2">Step 4: Execution Plan</h2>
      <p className="text-gray-600">Based on the information provided, here is how I will structure your System Prompt:</p>

      <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm space-y-4">
        <ul className="space-y-3">
            {data.aiPlan.map((point, idx) => (
                <li key={idx} className="flex items-start space-x-3">
                    <span className="flex-shrink-0 w-6 h-6 rounded-full bg-green-100 text-green-600 flex items-center justify-center text-sm font-bold">
                        ✓
                    </span>
                    <span className="text-gray-800">{point}</span>
                </li>
            ))}
        </ul>
      </div>

      <div className="flex justify-end pt-4">
        <button
          onClick={onNext}
          className="px-6 py-3 rounded-lg font-semibold text-white bg-n8n-primary hover:bg-orange-600 shadow-lg transition-all"
        >
          Generate Final Prompt &rarr;
        </button>
      </div>
    </div>
  );
};

export default Step4Confirmation;