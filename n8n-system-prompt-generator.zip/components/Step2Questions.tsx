import React from 'react';
import { FormData } from '../types';

interface Props {
  data: FormData;
  updateData: (fields: Partial<FormData>) => void;
  onNext: () => void;
  isLoading: boolean;
}

const Step2Questions: React.FC<Props> = ({ data, updateData, onNext, isLoading }) => {
  const handleAnswerChange = (index: number, value: string) => {
    const newAnswers = { ...data.userAnswers, [index]: value };
    updateData({ userAnswers: newAnswers });
  };

  const allAnswered = data.aiQuestions.length > 0 && 
    data.aiQuestions.every((_, idx) => data.userAnswers[idx]?.trim().length > 0);

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 space-y-4">
        <div className="w-12 h-12 border-4 border-n8n-primary border-t-transparent rounded-full animate-spin"></div>
        <p className="text-gray-600 font-medium">Analyzing your workflow and intent...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <h2 className="text-2xl font-bold text-n8n-secondary mb-2">Step 2: Clarification</h2>
      <p className="text-gray-600 mb-6">The AI has generated a few questions to better understand your needs.</p>

      {data.aiQuestions.map((q, index) => (
        <div key={index} className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm">
          <label className="block text-sm font-bold text-gray-800 mb-2">
            {index + 1}. {q}
          </label>
          <input
            type="text"
            className="w-full p-3 border border-gray-300 rounded-md focus:ring-1 focus:ring-n8n-secondary focus:border-n8n-secondary"
            placeholder="Your answer..."
            value={data.userAnswers[index] || ''}
            onChange={(e) => handleAnswerChange(index, e.target.value)}
          />
        </div>
      ))}

      <div className="flex justify-end pt-4">
        <button
          onClick={onNext}
          disabled={!allAnswered}
          className={`px-6 py-3 rounded-lg font-semibold text-white transition-all ${
            allAnswered
              ? 'bg-n8n-primary hover:bg-orange-600 shadow-lg'
              : 'bg-gray-400 cursor-not-allowed'
          }`}
        >
          Next: Configure Headers &rarr;
        </button>
      </div>
    </div>
  );
};

export default Step2Questions;